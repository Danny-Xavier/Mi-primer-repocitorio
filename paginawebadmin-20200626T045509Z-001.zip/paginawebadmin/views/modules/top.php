<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

<div class="row" id="top" >
			
	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center" >

		<img class="img-circle" src="views/images/mision.jpg" with="40px" >
		<h3>MISIÓN</h3>
		<p>
		   Lorem ipsum dolor sit amet, consectet elitlthwtg
		   wergijweriogj oeirjtwoierjt wejrt ijweoirtj oier
		   jt ewoirtji ew rtoijweri tjweirjt iewjrtirgerger
           </p>
		

	</div>

	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">

		<img class="img-circle" src="views/images/valores.jpg" width="40%">
		<h3>FILOSOFÍA</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisic
		   ing elitdlkgmgwergerkgm ewrkltm ewkrlt etker tke
		   er tlkermt kwemrtkmewlkrterklmtkerw lk  ekrtm me
		   rtk.
		</p>

	</div>

	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">

		<img class="img-circle" src="views/images/vision.jpg" width="40%">
		<h3>VISIÓN</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisic
		   ing elit ergt ert wert wert wert wert wert wertw
		   rt we wetgwetwertwertwertertwertg wrt.
		</p>

	</div>



</div>
